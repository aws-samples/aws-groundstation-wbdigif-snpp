#!/bin/bash
# First, find out where we are
case $0 in
         /*)  SHELLFILE=$0 ;;
		./*)  SHELLFILE=${PWD}${0#.} ;;
        ../*) SHELLFILE=${PWD%/*}${0#..} ;;
          *)  SHELLFILE=$(type -P "$0") ; if [ "${SHELLFILE:0:1}" != "/" ]; then SHELLFILE="${PWD}/$SHELLFILE" ; fi ;;
esac

# readlink -m makes sure SHELLDIR is a simple absolute path
SHELLDIR=`readlink -m "${SHELLFILE%/*}"`

# 6.0: So the Simulcast root directory should be in ths same directory as this script. Make it an absolute path
SC_HOME="$SHELLDIR"
SC_LIB=$SC_HOME/lib
SC_JDK=$SC_HOME/jre

# 7.0: Run the java in Simulcast's standalone JRE
$SC_JDK/bin/java -cp $SC_HOME/lib/simulcast.jar gov.nasa.gsfc.aisb.simulcast.Install $0
